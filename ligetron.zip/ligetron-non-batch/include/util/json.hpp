#pragma once

#include <nlohmann/json.hpp>

namespace ligero::aya {

using json = nlohmann::json;

}
